﻿namespace CapturandoDaddos
{
    partial class FrmDados
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDados));
            this.lblInteiro = new System.Windows.Forms.Label();
            this.txtInteiro = new System.Windows.Forms.TextBox();
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.txtBoleano = new System.Windows.Forms.TextBox();
            this.lblTexto = new System.Windows.Forms.Label();
            this.lblDecimal = new System.Windows.Forms.Label();
            this.lblBoleano = new System.Windows.Forms.Label();
            this.bntEnviar = new System.Windows.Forms.Button();
            this.bntLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblInteiro
            // 
            this.lblInteiro.AutoSize = true;
            this.lblInteiro.Font = new System.Drawing.Font("Cascadia Mono", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInteiro.ForeColor = System.Drawing.Color.Orange;
            this.lblInteiro.Location = new System.Drawing.Point(52, 70);
            this.lblInteiro.Name = "lblInteiro";
            this.lblInteiro.Size = new System.Drawing.Size(152, 43);
            this.lblInteiro.TabIndex = 0;
            this.lblInteiro.Text = "Inteiro";
            this.lblInteiro.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtInteiro
            // 
            this.txtInteiro.Font = new System.Drawing.Font("Cascadia Mono", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInteiro.Location = new System.Drawing.Point(60, 139);
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(286, 39);
            this.txtInteiro.TabIndex = 1;
            this.txtInteiro.TextChanged += new System.EventHandler(this.txtInteiro_TextChanged);
            // 
            // txtDecimal
            // 
            this.txtDecimal.Font = new System.Drawing.Font("Cascadia Mono", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimal.Location = new System.Drawing.Point(60, 297);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(286, 39);
            this.txtDecimal.TabIndex = 2;
            this.txtDecimal.TextChanged += new System.EventHandler(this.txtDecimal_TextChanged);
            // 
            // txtTexto
            // 
            this.txtTexto.Font = new System.Drawing.Font("Cascadia Mono", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTexto.Location = new System.Drawing.Point(448, 139);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(286, 39);
            this.txtTexto.TabIndex = 3;
            this.txtTexto.TextChanged += new System.EventHandler(this.txtTexto_TextChanged);
            // 
            // txtBoleano
            // 
            this.txtBoleano.Font = new System.Drawing.Font("Cascadia Mono", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoleano.Location = new System.Drawing.Point(448, 297);
            this.txtBoleano.Name = "txtBoleano";
            this.txtBoleano.Size = new System.Drawing.Size(286, 39);
            this.txtBoleano.TabIndex = 4;
            this.txtBoleano.TextChanged += new System.EventHandler(this.txtBoleano_TextChanged);
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Font = new System.Drawing.Font("Cascadia Mono", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto.ForeColor = System.Drawing.Color.Orange;
            this.lblTexto.Location = new System.Drawing.Point(440, 70);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(114, 43);
            this.lblTexto.TabIndex = 5;
            this.lblTexto.Text = "Texto";
            this.lblTexto.Click += new System.EventHandler(this.lblTexto_Click);
            // 
            // lblDecimal
            // 
            this.lblDecimal.AutoSize = true;
            this.lblDecimal.Font = new System.Drawing.Font("Cascadia Mono", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDecimal.ForeColor = System.Drawing.Color.Orange;
            this.lblDecimal.Location = new System.Drawing.Point(52, 223);
            this.lblDecimal.Name = "lblDecimal";
            this.lblDecimal.Size = new System.Drawing.Size(152, 43);
            this.lblDecimal.TabIndex = 6;
            this.lblDecimal.Text = "Decimal";
            this.lblDecimal.Click += new System.EventHandler(this.lblDecimal_Click);
            // 
            // lblBoleano
            // 
            this.lblBoleano.AutoSize = true;
            this.lblBoleano.Font = new System.Drawing.Font("Cascadia Mono", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBoleano.ForeColor = System.Drawing.Color.Orange;
            this.lblBoleano.Location = new System.Drawing.Point(440, 223);
            this.lblBoleano.Name = "lblBoleano";
            this.lblBoleano.Size = new System.Drawing.Size(152, 43);
            this.lblBoleano.TabIndex = 7;
            this.lblBoleano.Text = "Boleano";
            this.lblBoleano.Click += new System.EventHandler(this.lblBoleano_Click);
            // 
            // bntEnviar
            // 
            this.bntEnviar.BackColor = System.Drawing.Color.LightGreen;
            this.bntEnviar.ForeColor = System.Drawing.Color.Black;
            this.bntEnviar.Location = new System.Drawing.Point(198, 393);
            this.bntEnviar.Name = "bntEnviar";
            this.bntEnviar.Size = new System.Drawing.Size(167, 45);
            this.bntEnviar.TabIndex = 8;
            this.bntEnviar.Text = "Enviar";
            this.bntEnviar.UseVisualStyleBackColor = false;
            this.bntEnviar.Click += new System.EventHandler(this.bntEnviar_Click);
            // 
            // bntLimpar
            // 
            this.bntLimpar.BackColor = System.Drawing.Color.Firebrick;
            this.bntLimpar.ForeColor = System.Drawing.Color.Black;
            this.bntLimpar.Location = new System.Drawing.Point(404, 393);
            this.bntLimpar.Name = "bntLimpar";
            this.bntLimpar.Size = new System.Drawing.Size(167, 45);
            this.bntLimpar.TabIndex = 9;
            this.bntLimpar.Text = "Limpar";
            this.bntLimpar.UseVisualStyleBackColor = false;
            this.bntLimpar.Click += new System.EventHandler(this.bntLimpar_Click);
            // 
            // FrmDados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Khaki;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bntLimpar);
            this.Controls.Add(this.bntEnviar);
            this.Controls.Add(this.lblBoleano);
            this.Controls.Add(this.lblDecimal);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.txtBoleano);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.txtInteiro);
            this.Controls.Add(this.lblInteiro);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmDados";
            this.Text = "Capturando dados na tela";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInteiro;
        private System.Windows.Forms.TextBox txtInteiro;
        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.TextBox txtBoleano;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Label lblDecimal;
        private System.Windows.Forms.Label lblBoleano;
        private System.Windows.Forms.Button bntEnviar;
        private System.Windows.Forms.Button bntLimpar;
    }
}

