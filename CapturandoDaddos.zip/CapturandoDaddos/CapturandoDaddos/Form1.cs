﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapturandoDaddos
{
    public partial class FrmDados : Form
    {
        public FrmDados()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("clicou no inteiro");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("alterou inteiro");
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("alterou texto");
        }

        private void txtDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("alterou decimal");
        }

        private void txtBoleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("alterou decimal");
        }

        private void bntEnviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("clicou no botao enviar");
        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("clicou no botao limpar");
        }

        private void lblTexto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("clicou no texto");
        }

        private void lblDecimal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("clicou no decimal");
        }

        private void lblBoleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("clicou no boleano");
        }
    }
}
