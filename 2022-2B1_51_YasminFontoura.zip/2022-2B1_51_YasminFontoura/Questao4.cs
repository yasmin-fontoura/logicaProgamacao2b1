﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2022_2B1_51_YasminFontoura
{
    public partial class Questao4 : Form
    {
        public Questao4()
        {
            InitializeComponent();
        }

        private void bntCalcular_Click(object sender, EventArgs e)
        {
            float mensalidade = float.Parse(txtMensalidade.Text);
            float total;

            total= mensalidade - (mensalidade * 30 / 100);

            lblDesconto.Text = "Mensalidade com desconto=" + total;
        }
    }
}
