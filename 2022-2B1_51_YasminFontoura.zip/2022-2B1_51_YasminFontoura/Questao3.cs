﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2022_2B1_51_YasminFontoura
{
    public partial class Questao3 : Form
    {
        public Questao3()
        {
            InitializeComponent();
        }


        private void bntCalcular_Click(object sender, EventArgs e)
        {
            float peso = float.Parse(txtPeso.Text);
            float altura = float.Parse(txtAltura.Text);
            float total;

            total = peso / (altura * altura);

            lblIMC.Text = "IMC=" + total; 
        }
    }
}
