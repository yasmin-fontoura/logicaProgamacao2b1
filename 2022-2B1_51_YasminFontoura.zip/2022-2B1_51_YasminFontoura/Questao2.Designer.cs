﻿namespace _2022_2B1_51_YasminFontoura
{
    partial class Questao2
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Questao2));
            this.pnlBege = new System.Windows.Forms.Panel();
            this.txtPrecisa_De_Receita = new System.Windows.Forms.TextBox();
            this.txtConcentracao = new System.Windows.Forms.TextBox();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblPrecisa_De_Receita = new System.Windows.Forms.Label();
            this.lblConcentracao = new System.Windows.Forms.Label();
            this.lblValor = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblRemedio = new System.Windows.Forms.Label();
            this.bntPesquisar = new System.Windows.Forms.Button();
            this.pnlBege.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBege
            // 
            this.pnlBege.BackColor = System.Drawing.Color.AntiqueWhite;
            this.pnlBege.Controls.Add(this.txtPrecisa_De_Receita);
            this.pnlBege.Controls.Add(this.txtConcentracao);
            this.pnlBege.Controls.Add(this.txtValor);
            this.pnlBege.Controls.Add(this.txtNome);
            this.pnlBege.Controls.Add(this.lblPrecisa_De_Receita);
            this.pnlBege.Controls.Add(this.lblConcentracao);
            this.pnlBege.Controls.Add(this.lblValor);
            this.pnlBege.Controls.Add(this.lblNome);
            this.pnlBege.Controls.Add(this.lblRemedio);
            this.pnlBege.Location = new System.Drawing.Point(-12, -12);
            this.pnlBege.Name = "pnlBege";
            this.pnlBege.Size = new System.Drawing.Size(413, 479);
            this.pnlBege.TabIndex = 0;
            // 
            // txtPrecisa_De_Receita
            // 
            this.txtPrecisa_De_Receita.Location = new System.Drawing.Point(56, 392);
            this.txtPrecisa_De_Receita.Name = "txtPrecisa_De_Receita";
            this.txtPrecisa_De_Receita.Size = new System.Drawing.Size(100, 20);
            this.txtPrecisa_De_Receita.TabIndex = 8;
            // 
            // txtConcentracao
            // 
            this.txtConcentracao.Location = new System.Drawing.Point(56, 303);
            this.txtConcentracao.Name = "txtConcentracao";
            this.txtConcentracao.Size = new System.Drawing.Size(100, 20);
            this.txtConcentracao.TabIndex = 7;
            // 
            // txtValor
            // 
            this.txtValor.Location = new System.Drawing.Point(56, 228);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(100, 20);
            this.txtValor.TabIndex = 6;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(56, 160);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 5;
            // 
            // lblPrecisa_De_Receita
            // 
            this.lblPrecisa_De_Receita.AutoSize = true;
            this.lblPrecisa_De_Receita.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecisa_De_Receita.Location = new System.Drawing.Point(51, 344);
            this.lblPrecisa_De_Receita.Name = "lblPrecisa_De_Receita";
            this.lblPrecisa_De_Receita.Size = new System.Drawing.Size(139, 25);
            this.lblPrecisa_De_Receita.TabIndex = 4;
            this.lblPrecisa_De_Receita.Text = "Precisa de receita:";
            // 
            // lblConcentracao
            // 
            this.lblConcentracao.AutoSize = true;
            this.lblConcentracao.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConcentracao.Location = new System.Drawing.Point(51, 264);
            this.lblConcentracao.Name = "lblConcentracao";
            this.lblConcentracao.Size = new System.Drawing.Size(113, 25);
            this.lblConcentracao.TabIndex = 3;
            this.lblConcentracao.Text = "Concentração:";
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor.Location = new System.Drawing.Point(51, 183);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(50, 25);
            this.lblValor.TabIndex = 2;
            this.lblValor.Text = "Valor:";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(51, 117);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(53, 25);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome:";
            // 
            // lblRemedio
            // 
            this.lblRemedio.AutoSize = true;
            this.lblRemedio.Font = new System.Drawing.Font("Bahnschrift Condensed", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemedio.Location = new System.Drawing.Point(112, 21);
            this.lblRemedio.Name = "lblRemedio";
            this.lblRemedio.Size = new System.Drawing.Size(168, 58);
            this.lblRemedio.TabIndex = 0;
            this.lblRemedio.Text = "Remedio:";
            // 
            // bntPesquisar
            // 
            this.bntPesquisar.BackColor = System.Drawing.Color.Bisque;
            this.bntPesquisar.Font = new System.Drawing.Font("Bahnschrift Condensed", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntPesquisar.Location = new System.Drawing.Point(516, 334);
            this.bntPesquisar.Name = "bntPesquisar";
            this.bntPesquisar.Size = new System.Drawing.Size(196, 66);
            this.bntPesquisar.TabIndex = 1;
            this.bntPesquisar.Text = "Pesquisar";
            this.bntPesquisar.UseVisualStyleBackColor = false;
            // 
            // Questao1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bntPesquisar);
            this.Controls.Add(this.pnlBege);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Questao1";
            this.Text = "Remedios";
            this.pnlBege.ResumeLayout(false);
            this.pnlBege.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBege;
        private System.Windows.Forms.TextBox txtPrecisa_De_Receita;
        private System.Windows.Forms.TextBox txtConcentracao;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblPrecisa_De_Receita;
        private System.Windows.Forms.Label lblConcentracao;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblRemedio;
        private System.Windows.Forms.Button bntPesquisar;
    }
}

