﻿namespace _2022_2B1_51_YasminFontoura
{
    partial class Questao4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.txtMensalidade = new System.Windows.Forms.TextBox();
            this.lblMensalidade_Preco = new System.Windows.Forms.Label();
            this.lblMensalidade = new System.Windows.Forms.Label();
            this.lblDesconto = new System.Windows.Forms.Label();
            this.bntCalcular = new System.Windows.Forms.Button();
            this.pnlPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.BackColor = System.Drawing.Color.OliveDrab;
            this.pnlPrincipal.Controls.Add(this.bntCalcular);
            this.pnlPrincipal.Controls.Add(this.lblDesconto);
            this.pnlPrincipal.Controls.Add(this.txtMensalidade);
            this.pnlPrincipal.Controls.Add(this.lblMensalidade_Preco);
            this.pnlPrincipal.Controls.Add(this.lblMensalidade);
            this.pnlPrincipal.Location = new System.Drawing.Point(142, 68);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Size = new System.Drawing.Size(501, 327);
            this.pnlPrincipal.TabIndex = 0;
            // 
            // txtMensalidade
            // 
            this.txtMensalidade.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMensalidade.Location = new System.Drawing.Point(41, 171);
            this.txtMensalidade.Name = "txtMensalidade";
            this.txtMensalidade.Size = new System.Drawing.Size(137, 33);
            this.txtMensalidade.TabIndex = 2;
            // 
            // lblMensalidade_Preco
            // 
            this.lblMensalidade_Preco.AutoSize = true;
            this.lblMensalidade_Preco.Font = new System.Drawing.Font("Bahnschrift Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensalidade_Preco.Location = new System.Drawing.Point(36, 125);
            this.lblMensalidade_Preco.Name = "lblMensalidade_Preco";
            this.lblMensalidade_Preco.Size = new System.Drawing.Size(118, 29);
            this.lblMensalidade_Preco.TabIndex = 1;
            this.lblMensalidade_Preco.Text = "Mensalidade:";
            // 
            // lblMensalidade
            // 
            this.lblMensalidade.AutoSize = true;
            this.lblMensalidade.Font = new System.Drawing.Font("Bahnschrift Condensed", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensalidade.Location = new System.Drawing.Point(137, 12);
            this.lblMensalidade.Name = "lblMensalidade";
            this.lblMensalidade.Size = new System.Drawing.Size(226, 58);
            this.lblMensalidade.TabIndex = 0;
            this.lblMensalidade.Text = "Mensalidade";
            // 
            // lblDesconto
            // 
            this.lblDesconto.AutoSize = true;
            this.lblDesconto.Font = new System.Drawing.Font("Bahnschrift Condensed", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesconto.Location = new System.Drawing.Point(36, 234);
            this.lblDesconto.Name = "lblDesconto";
            this.lblDesconto.Size = new System.Drawing.Size(233, 29);
            this.lblDesconto.TabIndex = 3;
            this.lblDesconto.Text = "Mensalidade com desconto=";
            // 
            // bntCalcular
            // 
            this.bntCalcular.BackColor = System.Drawing.Color.OliveDrab;
            this.bntCalcular.Font = new System.Drawing.Font("Bahnschrift Condensed", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntCalcular.ForeColor = System.Drawing.Color.Ivory;
            this.bntCalcular.Location = new System.Drawing.Point(331, 158);
            this.bntCalcular.Name = "bntCalcular";
            this.bntCalcular.Size = new System.Drawing.Size(119, 48);
            this.bntCalcular.TabIndex = 4;
            this.bntCalcular.Text = "Calcular";
            this.bntCalcular.UseVisualStyleBackColor = false;
            this.bntCalcular.Click += new System.EventHandler(this.bntCalcular_Click);
            // 
            // Questao4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlPrincipal);
            this.Name = "Questao4";
            this.Text = "Questao3";
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.TextBox txtMensalidade;
        private System.Windows.Forms.Label lblMensalidade_Preco;
        private System.Windows.Forms.Label lblMensalidade;
        private System.Windows.Forms.Label lblDesconto;
        private System.Windows.Forms.Button bntCalcular;
    }
}